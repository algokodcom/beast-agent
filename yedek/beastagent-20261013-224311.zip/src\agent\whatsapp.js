'use strict';

/* WhatsApp bridge — Baileys tabanlı. QR ile eşleme, auth %APPDATA%\beast\wa-auth,
   gelen özel mesajlar onIncoming(jid, text)'e düşer, send(jid,text) cevap döner. */

const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');

let baileys = null;
try {
  baileys = require('@whiskeysockets/baileys');
} catch (e) {
  baileys = null;
}

/* WAMessageStatus: 0=ERROR 1=PENDING 2=SERVER_ACK(gönderildi)
   3=DELIVERY_ACK(teslim) 4=READ(okundu) 5=PLAYED(ses çalındı) */
const STATUS_LABELS = {
  0: 'hata',
  1: 'bekliyor',
  2: 'gönderildi ✓',
  3: 'teslim ✓✓',
  4: 'okundu ✓✓',
  5: 'çalındı ✓✓',
};

function statusLabel(status) {
  return STATUS_LABELS[status] || `bilinmeyen(${status})`;
}

/* Baileys kendi debug çıktılarını bastırmak için main enjekte etmezse no-op */
function waLogSafe(line) {
  try { console.log(`[WA] ${line}`); } catch {}
}

const TRACK_CAP = 500;

/* ---------- TTS → WhatsApp sesli not (OGG/Opus) ---------- */

let _ffmpegPath = null;
function getFfmpegPath() {
  if (_ffmpegPath !== null) return _ffmpegPath;
  try { _ffmpegPath = require('ffmpeg-static') || ''; } catch { _ffmpegPath = ''; }
  return _ffmpegPath;
}

function runFfmpeg(args, input) {
  return new Promise((resolve, reject) => {
    try {
      const { spawn } = require('child_process');
      const p = spawn(getFfmpegPath(), args, { windowsHide: true });
      const out = [];
      let err = '';
      p.stdout.on('data', (c) => out.push(c));
      p.stderr.on('data', (c) => { if (err.length < 400) err += c.toString(); });
      p.on('error', reject);
      p.on('close', (code) => {
        if (code !== 0) return reject(new Error(`ffmpeg ${code}: ${err.slice(0, 200)}`));
        resolve(Buffer.concat(out));
      });
      p.stdin.on('error', () => {});
      p.stdin.write(input);
      p.stdin.end();
    } catch (e) {
      reject(e);
    }
  });
}

/* Herhangi bir ses buffer'ı → OGG/Opus (WhatsApp sesli not formatı). Zaten OggS ise olduğu gibi döner. */
async function toVoiceOggOpus(buf) {
  if (buf.length > 4 && buf.subarray(0, 4).toString('latin1') === 'OggS') return buf;
  const ff = getFfmpegPath();
  if (!ff) throw new Error('ffmpeg bulunamadı');
  return runFfmpeg([
    '-hide_banner', '-loglevel', 'error',
    '-i', 'pipe:0',
    '-c:a', 'libopus', '-b:a', '48k', '-ar', '24000', '-ac', '1',
    '-application', 'voip', '-vbr', 'on',
    '-f', 'ogg', 'pipe:1',
  ], buf);
}

/* Sesli not dalga formu: 64 segmentlik normalize genlik histogramı (Uint8Array) */
async function audioWaveform(buf) {
  try {
    const ff = getFfmpegPath();
    if (!ff) return undefined;
    const pcm = await runFfmpeg([
      '-hide_banner', '-loglevel', 'error',
      '-i', 'pipe:0', '-f', 's16le', '-ar', '16000', '-ac', '1', 'pipe:1',
    ], buf);
    const SEG = 64;
    const step = Math.max(1, Math.floor(pcm.length / 2 / SEG));
    const wave = new Uint8Array(SEG);
    let max = 1;
    for (let i = 0; i < SEG; i++) {
      let sum = 0;
      const start = i * step;
      for (let j = 0; j < step; j++) {
        const off = (start + j) * 2;
        if (off + 1 < pcm.length) sum += Math.abs(pcm.readInt16LE(off));
      }
      const v = Math.round(sum / step);
      wave[i] = v;
      if (v > max) max = v;
    }
    for (let i = 0; i < SEG; i++) wave[i] = Math.min(255, Math.round((wave[i] / max) * 255));
    return wave;
  } catch {
    return undefined;
  }
}

/* lastKnownPresence etiketleri */
const PRESENCE_LABELS = {
  available: 'çevrimiçi',
  composing: 'yazıyor',
  recording: 'ses kaydediyor',
  paused: '',
  unavailable: 'çevrimdışı',
};

class WhatsAppBridge {
  constructor({ authDir, emit, onIncoming, onReaction }) {
    this.authDir = authDir;
    this.emit = emit || (() => {});
    this.onIncoming = onIncoming || null;
    this.onReaction = onReaction || null;
    this.sock = null;
    this.connected = false;
    this.user = null;
    this.stopping = false;
    this.reconnectTimer = null;
    this._tracked = new Map(); // msgId -> { jid, preview, ts, status, receiptDetail }
    this._watchJids = new Set(); // presence aboneliği tutulacak sohbetler
    this._seenIds = new Set(); // işlenen mesaj id'leri — offline replay + notify çift işlemeyi önler
    this._lidPn = new Map(); // LID jid -> gerçek telefon numarası (831...@lid → 905...)
  }

  /* Ham JID'den telefon numarası — YALNIZ PN (s.whatsapp.net) kökenliyse.
     rc9+ sarmalayıcı 'alt:' ön eki ve cihaz soneki (:12) soyulur; @lid gibi
     adresler PN sayılmaz (aksi halde LID rakamı numara sanılıp allow listesi
     hiç eşleşmiyordu). */
  _pnOnly(jid) {
    let s = String(jid || '');
    if (!s) return '';
    if (s.startsWith('alt:')) s = s.slice(4);
    const at = s.indexOf('@');
    if (at < 0) return ''; // host yok — LID/PN ayrımı yapılamaz
    const host = s.slice(at + 1);
    if (host !== 's.whatsapp.net' && host !== 'hosted') return ''; // @lid vs. → PN değil
    s = s.slice(0, at).split(':')[0];
    return /^\d{6,}$/.test(s) ? s : '';
  }

  /* LID jid → gerçek telefon numarası. Baileys'in LID eşleme deposu
     (signalRepository.lidMapping) auth klasöründe kalıcıdır — uygulama
     kapansa bile eşleme korunur, allow listesi TELEFON NUMARASIYLA
     eşleşmeye devam eder. Bilinmeyen LID'de '' döner (LID rakamı
     numara sanılmaz). */
  async _lidToPn(lidJid) {
    const lid = String(lidJid || '');
    if (!lid.endsWith('@lid')) return '';
    const cached = this._lidPn.get(lid);
    if (cached) return cached;
    let pn = '';
    try {
      const store = this.sock && this.sock.signalRepository && this.sock.signalRepository.lidMapping;
      if (store && typeof store.getPNForLID === 'function') {
        pn = this._pnOnly(await store.getPNForLID(lid));
      }
    } catch {}
    /* negatif sonuçlar cache'lenmez: eşleme 'lid-mapping.update' ile
       sonradan gelebilir, her mesajda yeniden denensin */
    if (pn) this._lidPn.set(lid, pn);
    return pn;
  }

  /* Tek LID↔PN eşlemesini önbelleğe al */
  _cacheLidPn(m) {
    try {
      const lid = String((m && m.lid) || '');
      const pn = this._pnOnly(m && m.pn);
      if (lid.endsWith('@lid') && pn) this._lidPn.set(lid, pn);
    } catch {}
  }

  /* Kişi listesinden LID↔PN eşlemelerini önbelleğe al (contacts.upsert /
     messaging-history.set) */
  _cacheLidPnList(list) {
    for (const c of list || []) {
      this._cacheLidPn({ lid: c && (c.lid || c.id), pn: c && (c.phoneNumber || c.pn) });
    }
  }

  /* main tarafı waChats anahtarlarını bildirir; bağlantı varsa anında abone olunur */
  setWatchJids(jids) {
    this._watchJids = new Set(jids || []);
    if (this.sock && this.connected) {
      this._subscribePresence().catch(() => {});
    }
  }

  async _subscribePresence() {
    if (!this.sock || typeof this.sock.presenceSubscribe !== 'function') return;
    for (const jid of this._watchJids) {
      try {
        await this.sock.presenceSubscribe(jid);
      } catch {}
    }
  }

  /* Baileys medya akışını buffer'a dök */
  async _mediaBuffer(desc, type) {
    if (!baileys || typeof baileys.downloadContentFromMessage !== 'function') {
      throw new Error('medya indirme desteklenmiyor');
    }
    const stream = await baileys.downloadContentFromMessage(desc, type);
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    return Buffer.concat(chunks);
  }

  get available() {
    return !!baileys;
  }

  snapshot() {
    return {
      status: this.connected ? 'connected' : this.sock ? 'connecting' : 'disconnected',
      user: this.user,
      available: this.available,
    };
  }

  _emitStatus(s) {
    this.emit({ type: 'status', ...s });
  }

  async start() {
    if (!baileys) throw new Error('Baileys kurulu değil: npm i @whiskeysockets/baileys qrcode');
    if (this.sock) return;
    this.stopping = false;

    const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = baileys;
    fs.mkdirSync(this.authDir, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(this.authDir);
    let version;
    try {
      ({ version } = await fetchLatestBaileysVersion());
    } catch {
      version = undefined;
    }

    this.sock = makeWASocket({
      version,
      auth: state,
      printQRInTerminal: false,
      browser: ['Beast Agent', 'Chrome', '1.0.0'],
      syncFullHistory: false,
      /* false OLMALI: bot "çevrimiçi" işaretlenirse WhatsApp sunucusu kesintide
         gelen mesajları bu cihaz için kuyruklamayı aksatıyor. false ile kesintideki
         mesajlar sunucuda bekler, bağlantı dönünce 'append' upsert'iyle iletilir. */
      markOnlineOnConnect: false,
    });

    this.sock.ev.on('creds.update', saveCreds);

    this.sock.ev.on('connection.update', async (u) => {
      try {
        if (u.qr) {
          const dataUrl = await QRCode.toDataURL(u.qr, { margin: 1, width: 240 });
          this.connected = false;
          this._emitStatus({ status: 'qr', qr: dataUrl });
        }
        if (u.connection === 'open') {
          this.connected = true;
          const su = this.sock.user || {};
          this.user = [su.name || su.verifiedName || '', su.id ? String(su.id).split(':')[0] : '']
            .filter(Boolean)
            .join(' · ');
          /* mention/reply kontrolü için ham id (örn 1234:56@s.whatsapp.net) */
          this._userIdRaw = String(su.id || '');
          this._emitStatus({ status: 'connected', user: this.user });
          this.sock.sendPresenceUpdate('available').catch(() => {});
          this._subscribePresence().catch(() => {});
        }
        if (u.connection === 'close') {
          const code = u.lastDisconnect && u.lastDisconnect.error &&
            u.lastDisconnect.error.output && u.lastDisconnect.error.output.statusCode;
          const loggedOut = code === DisconnectReason.loggedOut;
          this.sock = null;
          if (this.stopping) {
            this.connected = false;
            this._emitStatus({ status: 'disconnected' });
            return;
          }
          if (loggedOut) {
            try {
              fs.rmSync(this.authDir, { recursive: true, force: true });
            } catch {}
            this.connected = false;
            this.user = null;
            this._emitStatus({ status: 'logged-out' });
            return;
          }
          this._emitStatus({ status: 'reconnecting' });
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = setTimeout(() => this.start().catch(() => {}), 3000);
        }
      } catch (e) {
        this._emitStatus({ status: 'error', error: String((e && e.message) || e) });
      }
    });

    this.sock.ev.on('messages.upsert', (m) => this._handleMessages(m));

    /* LID → gerçek telefon eşlemeleri: allow listesi telefon numarasıyla
       eşleştiği için bu olaylardan gelen eşlemeler de önbelleğe alınır */
    this.sock.ev.on('lid-mapping.update', (m) => this._cacheLidPn(m));
    this.sock.ev.on('contacts.upsert', (list) => this._cacheLidPnList(list));
    this.sock.ev.on('messaging-history.set', (d) => this._cacheLidPnList(d && d.contacts));

    /* Teslim/okundu takibi — sadece kendi gönderdiklerimiz izlenir */
    this.sock.ev.on('messages.update', (ups) => this._handleStatusUpdates(ups));
    this.sock.ev.on('message-receipt.update', (rs) => this._handleReceipts(rs));

    /* Karşı tarafın çevrimiçi/yazıyor durumu — izlenen sohbetler için */
    this.sock.ev.on('presence.update', (u) => this._handlePresence(u));
  }

  _handlePresence(u) {
    try {
      if (!u || !u.id) return;
      const presences = u.presences || {};
      for (const [pid, p] of Object.entries(presences)) {
        const st = p && p.lastKnownPresence;
        if (!st || !(st in PRESENCE_LABELS)) continue;
        this.emit({
          type: 'presence',
          jid: u.id,
          participant: pid,
          presence: st,
          label: PRESENCE_LABELS[st],
        });
      }
    } catch {}
  }

  _trackOutgoing(jid, preview, ret) {
    try {
      const id = ret && ret.key && ret.key.id;
      if (!id) return;
      if (this._tracked.size >= TRACK_CAP) {
        const first = this._tracked.keys().next().value;
        this._tracked.delete(first);
      }
      this._tracked.set(id, { jid: String(jid || ''), preview: String(preview || '').slice(0, 40), ts: Date.now(), status: 1, receiptDetail: '' });
      this.emit({ type: 'send', id, jid, preview: this._tracked.get(id).preview });
    } catch {}
  }

  _handleStatusUpdates(ups) {
    for (const up of ups || []) {
      try {
        /* bazı Baileys sürümleri tepkiyi update içinde taşır */
        const rmUp = (up && up.update && (up.update.reactionMessage ||
          (up.update.message && up.update.message.reactionMessage))) || null;
        if (rmUp) {
          this._handleReaction({ key: up.key }, rmUp);
          continue;
        }
        const st = up && up.update && up.update.status;
        const id = up && up.key && up.key.id;
        if (typeof st !== 'number' || !id) continue;
        const t = this._tracked.get(id);
        if (!t || st === t.status) continue; // yalnızca bizim mesajlarımız + değişim varsa
        t.status = st;
        this.emit({ type: 'tick', id, jid: t.jid, status: st, label: statusLabel(st), preview: t.preview });
      } catch {}
    }
  }

  _handleReceipts(rs) {
    for (const r of rs || []) {
      try {
        const rc = r && r.receipt;
        const id = r && r.key && r.key.id;
        const t = id && this._tracked.get(id);
        if (!t || !rc) continue;
        const bits = [];
        if (rc.deliveryTimestamp) bits.push(`teslim=${new Date(rc.deliveryTimestamp * 1000).toISOString()}`);
        else if (rc.deliveredAt) bits.push(`teslim=${new Date(rc.deliveredAt).toISOString()}`);
        if (rc.readTimestamp) bits.push(`okundu=${new Date(rc.readTimestamp * 1000).toISOString()}`);
        else if (rc.readAt) bits.push(`okundu=${new Date(rc.readAt).toISOString()}`);
        if (rc.playedTimestamp) bits.push(`çalındı=${new Date(rc.playedTimestamp * 1000).toISOString()}`);
        else if (rc.playedAt) bits.push(`çalındı=${new Date(rc.playedAt).toISOString()}`);
        const detail = bits.join(' ');
        if (!detail || detail === t.receiptDetail) continue;
        t.receiptDetail = detail;
        this.emit({ type: 'receipt', id, jid: t.jid, preview: t.preview, detail });
      } catch {}
    }
  }

  _handleMessages(m) {
    /* 'notify'  = canlı mesaj akışı
       'append' = bağlantı kesintisinde KAÇIRILMIŞ mesajlar — bağlantı dönünce
                  sunucu bunları oynatır; FALLOUT sorunu tam olarak burasıydı:
                  yalnızca 'notify' işlendiği için kesintideki mesajlar sessizce
                  düşüyor ve cevapsız kalıyordu. 'append' içindeki eski history
                  kayıtlarını elemek için son 15 dk tazelik filtresi kullanılır. */
    if (m.type !== 'notify' && m.type !== 'append') return;
    const nowMs = Date.now();
    for (const msg of m.messages || []) {
      /* aynı mesaj hem 'append' hem 'notify' ile gelebilir — ID dedup */
      const mid = msg.key && msg.key.id;
      if (mid) {
        if (this._seenIds.has(mid)) continue;
        this._seenIds.add(mid);
        if (this._seenIds.size > 600) {
          for (const k of [...this._seenIds].slice(0, 300)) this._seenIds.delete(k);
        }
      }
      /* tepkiler ayrı kanal: onay kapısı bunları dinler */
      const rm = msg.message && msg.message.reactionMessage;
      if (rm) {
        this._handleReaction(msg, rm);
        continue;
      }
      if (m.type === 'append') {
        const ts = Number(msg.messageTimestamp) || 0;
        const tsMs = ts > 1e12 ? ts : ts * 1000; // saniye/ms normalizasyonu
        if (!tsMs || nowMs - tsMs > 15 * 60 * 1000) continue; // eski history — işleme
        try {
          waLogSafe(`offline/append mesaj işleniyor (kesintiden kalan, ${new Date(tsMs).toISOString()})`);
        } catch {}
      }
      this._processIncoming(msg).catch(() => {});
    }
  }

  _handleReaction(msg, rm) {
    try {
      if (!rm || !rm.key || !rm.key.id) return;
      if (!this.onReaction) {
        this.emit({ type: 'reaction-unhandled', targetId: String(rm.key.id), reason: 'onReaction kanca yok' });
        return;
      }
      /* Baileys bazı sürümlerde tepkiyi kendi mesajı gibi işaretleyebiliyor;
         bizim onay kartımıza gelen tepkilerden kendi attıklarımız zaten yoktur */
      const jid = String(rm.key.remoteJid || msg.key.remoteJid || '');
      if (!jid) return;
      let senderNum = '';
      const raw = msg.key.participant || msg.key.remoteJidAlt || jid;
      const num = String(raw).split('@')[0].split(':')[0];
      if (/^\d+$/.test(num)) senderNum = num;
      const emoji = String(rm.text || '');
      waLogSafe(`reaction event ← target=${String(rm.key.id)} emoji=${JSON.stringify(emoji)} chat=${jid} sender=+${senderNum}`);
      this.emit({
        type: 'reaction',
        jid,
        targetId: String(rm.key.id),
        emoji,
        sender: senderNum,
      });
      this.onReaction(jid, String(rm.key.id), emoji, senderNum);
    } catch {}
  }

  /* Tek mesajı işle: metin + medya (resim/ses/belge) çıkarımı.
     Grup sohbetleri (@g.us) de kabul edilir; payload.isGroup ile işaretlenir,
     bot @mention edilmişse payload.mentioned=true gelir. */
  async _processIncoming(msg) {
    try {
      const jid = msg.key && msg.key.remoteJid;
      if (!jid) return;
      if (jid === 'status@broadcast' || jid.endsWith('@newsletter')) return;
      /* botun kendi kimliği: telefon base'i + LID base'i (LID dönemi) */
      const meBase = String(this._userIdRaw || '').split('@')[0].split(':')[0];
      const lidBase = String((this.sock && this.sock.user && this.sock.user.lid) || '').split('@')[0].split(':')[0];
      /* KENDİ KENDİNE SOHBET (Saved Messages): kullanıcı kendi numarasını izinliye
         ekleyip kendi sohbetinden bota yazabilsin. Bu sohbetteki HER mesaj fromMe
         gelir; botun KENDİ gönderdiği mesajlar (_tracked) filtrelenir → döngü yok.
         Diğer sohbetlerdeki elle yazılan fromMe mesajları bot etkilenmesin diye yutulur. */
      const selfChat = !!(meBase && (jid === meBase + '@s.whatsapp.net' || (lidBase && jid === lidBase + '@lid')));
      if (msg.key.fromMe) {
        if (this._tracked.has(String(msg.key.id))) return; // botun kendi cevabı — echo
        if (!selfChat) return;
      }
      const isGroup = jid.endsWith('@g.us');
      const participantJid = isGroup && msg.key.participant ? String(msg.key.participant) : '';
      const mm = msg.message || {};
      const text =
        mm.conversation ||
        (mm.extendedTextMessage && mm.extendedTextMessage.text) ||
        (mm.imageMessage && mm.imageMessage.caption) ||
        (mm.documentMessage && mm.documentMessage.caption) ||
        '';
      const t = String(text || '').trim();

      // gruplarda bot'un kendisi @mention edilmiş mi
      /* LİD DÖNEMİ UYARISI: mentionedJid artık çoğu zaman botun @lid numarasıyla
         gelir (telefon JID'i DEĞİL) — bu yüzden yalnız meBase ile karşılaştırma
         mention'ı ıskalıyordu. Şimdi: botun telefon base'i + LID base'i ikisiyle
         de eşitlik aranır; contextInfo görsel/video/belge caption'larından da alınır. */
      let mentioned = false;
      if (isGroup) {
        const ci =
          (mm.extendedTextMessage && mm.extendedTextMessage.contextInfo) ||
          (mm.imageMessage && mm.imageMessage.contextInfo) ||
          (mm.videoMessage && mm.videoMessage.contextInfo) ||
          (mm.documentMessage && mm.documentMessage.contextInfo) ||
          null;
        const men = (ci && ci.mentionedJid) || [];
        const baseOf = (j) => String(j || '').split('?')[0].split(':')[0].split('@')[0];
        for (const m of men) {
          const base = baseOf(m);
          if (base && ((meBase && base === meBase) || (lidBase && base === lidBase))) {
            mentioned = true;
            break;
          }
        }
        if (!mentioned && ci && ci.participant) {
          const pBase = baseOf(ci.participant);
          if ((meBase && pBase === meBase) || (lidBase && pBase === lidBase)) {
            mentioned = true; // mesajımıza reply verilmiş
          }
        }
        /* metin yedeği: @<bot numarası> elle yazılmışsa da mention sayılır */
        if (!mentioned && meBase && t.includes('@' + meBase)) mentioned = true;
      }

      // medya çıkarımı (varsa)
      let media = null;
      const MAX_MEDIA = 20 * 1024 * 1024;
      try {
        if (mm.imageMessage) {
          const buf = await this._mediaBuffer(mm.imageMessage, 'image');
          if (buf && buf.length && buf.length <= MAX_MEDIA) {
            media = { kind: 'image', buf, mimetype: mm.imageMessage.mimetype || 'image/jpeg', name: 'gorsel.jpg' };
          }
        } else if (mm.audioMessage) {
          const buf = await this._mediaBuffer(mm.audioMessage, 'audio');
          if (buf && buf.length && buf.length <= MAX_MEDIA) {
            media = { kind: 'audio', buf, mimetype: mm.audioMessage.mimetype || 'audio/ogg; codecs=opus' };
          }
        } else if (mm.documentMessage) {
          const buf = await this._mediaBuffer(mm.documentMessage, 'document');
          if (buf && buf.length && buf.length <= MAX_MEDIA) {
            media = { kind: 'document', buf, mimetype: mm.documentMessage.mimetype || 'application/octet-stream', name: mm.documentMessage.fileName || 'dosya' };
          }
        }
      } catch {}

      if (!t && !media) return;
      /* Yeni WA LID sistemi: gerçek numara önce remoteJidAlt / participantAlt
         içinde gelir. WhatsApp bu alanları göndermezse (LID çağı — DM jid'si
         …@lid olur) Baileys'in LID eşleme deposundan çözülür, böylece allow
         listesi TELEFON NUMARASIYLA (905…) eşleşmeye devam eder. */
      const alt =
        msg.key.remoteJidAlt ||
        (mm.extendedTextMessage && mm.extendedTextMessage.remoteJidAlt) ||
        msg.key.participantAlt ||
        '';
      let senderNum = this._pnOnly(alt);
      /* grup etiketi için katılımcının gerçek PN'si (LID çağında eşlemeden) */
      let pnLabel = this._pnOnly(msg.key.participantAlt);
      if (!senderNum) {
        /* DM'de jid, grupta katılımcı jid'si LID olabilir → eşleme deposundan çöz */
        const lidJid = String(jid).endsWith('@lid')
          ? jid
          : String(participantJid).endsWith('@lid') ? participantJid : '';
        if (lidJid) senderNum = await this._lidToPn(lidJid);
        if (!pnLabel && senderNum) pnLabel = senderNum;
      }
      if (!senderNum) {
        /* son çare: ham jid'in rakam kısmı (grup katılımcıları / PN jid) */
        senderNum = (participantJid || jid).split('@')[0].split(':')[0];
        if (!/^\d+$/.test(senderNum)) senderNum = '';
      }
      /* kendi kendine sohbette gönderen = botun telefon numarası — izin listesi
         telefon numarasıyla eşleşsin (LID self-chat'te jid @lid olur) */
      if (selfChat && meBase) senderNum = meBase;
      this.onIncoming(jid, {
        text: t,
        media,
        isGroup,
        participant: participantJid,
        /* LID çağında gerçek telefon: participantAlt; yoksa eşlemeden çözülen PN */
        participantPn: isGroup ? pnLabel : '',
        participantUsername: isGroup ? String(msg.key.participantUsername || '') : '',
        mentioned,
      }, senderNum);
    } catch {}
  }

  /* Cevap: başarı → { id }, başarısızlık → false (hata emit edilir, yutulmaz) */
  async send(jid, text) {
    if (!this.sock || !this.connected) return false;
    const txt = String(text).slice(0, 3500);
    let ret;
    try {
      ret = await this.sock.sendMessage(jid, { text: txt });
    } catch (e) {
      this.emit({
        type: 'send-error',
        jid,
        preview: txt.slice(0, 40),
        error: String((e && e.message) || e),
      });
      return false;
    }
    this._trackOutgoing(jid, txt, ret);
    const id = ret && ret.key && ret.key.id ? String(ret.key.id) : '';
    return id ? { id } : true;
  }

  /* Sesli not olarak yanıtla (TTS çıktısı mp3 buffer → WhatsApp sesli not formatı OGG/Opus'a çevrilir;
     ptt sesli notlar mp3 ile açılmaz, mutlaka audio/ogg; codecs=opus olmalı) */
  async sendAudio(jid, audioBuf) {
    if (!this.sock || !this.connected || !audioBuf) return false;
    try {
      let voice = audioBuf;
      let mime = 'audio/mpeg';
      let ptt = false;
      let waveform;
      try {
        voice = await toVoiceOggOpus(audioBuf);
        mime = 'audio/ogg; codecs=opus';
        ptt = true;
        waveform = await audioWaveform(voice);
      } catch {
        /* ffmpeg dönüşümü başarısızsa mp3'ü ptt'siz ses mesajı olarak dene */
        voice = audioBuf;
        mime = 'audio/mpeg';
        ptt = false;
      }
      const msg = { audio: voice, ptt, mimetype: mime };
      if (waveform) msg.waveform = waveform;
      const ret = await this.sock.sendMessage(jid, msg);
      this._trackOutgoing(jid, '[sesli yanıt]', ret);
      return true;
    } catch (e) {
      this.emit({ type: 'send-error', jid, preview: '[ses]', error: String((e && e.message) || e) });
      return false;
    }
  }

  /* Görsel gönder (jpeg/png buffer) — /screenshot vb. için */
  async sendImage(jid, imgBuf, caption) {
    if (!this.sock || !this.connected || !imgBuf) return false;
    try {
      const ret = await this.sock.sendMessage(jid, {
        image: imgBuf,
        caption: String(caption || '').slice(0, 800),
      });
      this._trackOutgoing(jid, '[görsel]', ret);
      return true;
    } catch (e) {
      this.emit({ type: 'send-error', jid, preview: '[görsel]', error: String((e && e.message) || e) });
      return false;
    }
  }

  /* Belge gönder (pdf/doc/xxx buffer) — ajanın send_file aracı için */
  async sendFile(jid, buf, fileName, caption, mimetype) {
    if (!this.sock || !this.connected || !buf) return false;
    try {
      const ret = await this.sock.sendMessage(jid, {
        document: buf,
        fileName: String(fileName || 'dosya'),
        mimetype: mimetype || 'application/octet-stream',
        caption: String(caption || '').slice(0, 800),
      });
      this._trackOutgoing(jid, '[dosya] ' + fileName, ret);
      return true;
    } catch (e) {
      this.emit({ type: 'send-error', jid, preview: '[dosya]', error: String((e && e.message) || e) });
      return false;
    }
  }

  /* Karşı chatta durum bildirimi: on=true → "yazıyor…", on=false → durdu */
  async setComposing(jid, on) {
    if (!this.sock || !this.connected) return;
    try {
      await this.sock.sendPresenceUpdate(on ? 'composing' : 'paused', jid);
    } catch {}
  }

  async stop() {
    this.stopping = true;
    clearTimeout(this.reconnectTimer);
    const s = this.sock;
    this.sock = null;
    this.connected = false;
    this.user = null;
    if (s) {
      try {
        await s.logout();
      } catch {
        try {
          s.end();
        } catch {}
      }
    }
    this._emitStatus({ status: 'disconnected' });
  }

  async resetAuth() {
    await this.stop();
    try {
      fs.rmSync(this.authDir, { recursive: true, force: true });
    } catch {}
  }
}

module.exports = { WhatsAppBridge, statusLabel };
