# 🚀 Beast Agent — Release Guide

> This file is for the person cutting a release. For end users, see: [README.md](README.md)

## ⚡ IMPORTANT: NO Exe / Installer DISTRIBUTION

Starting with v0.20.0, **no exe/Setup/Portable build is produced or published**. Distribution
is done entirely through **npm**:

- Install: `npm i -g beast-agent`
- Update: `beast update` (or `npm update -g beast-agent`)
- The in-app "Update" tab checks the version from the **npm registry**
  (electron-updater / latest.yml flow is not used).

## ⚡ One-Command Release

```bash
npm run release -- patch     # 0.20.0 → 0.20.1 (bug fixes)
npm run release -- minor     # 0.20.0 → 0.21.0 (new features)  ← usually this
npm run release -- major     # 0.20.0 → 1.0.0   (breaking change)
npm run release -- 0.21.0    # specific version
```

Script: `scripts/release.js` — runs 5 steps in order, automatically:

| # | Step | What it does |
|---|------|--------------|
| 1 | Version bump | bumps the version in `package.json` |
| 2 | Git sync | commit + `v< version >` tag + push to GitHub |
| 3 | GitHub Release | **source only** — creates the release with notes, uploads no assets |
| 4 | npm publish | publishes the `beast-agent` package to npm (requires NPM_TOKEN) |
| 5 | OneDrive backup | source copy into the `beast-v< version >` folder + info file |

## 🔧 Pre-Release Checklist

1. **GitHub login** (one-time): `gh auth login` → check with `gh auth status`
2. **npm token**: [npmjs.com → Access Tokens](https://www.npmjs.com/settings/~/tokens) → create a *Granular Token* (publish permission for the beast-agent package), then:
   ```cmd
   set NPM_TOKEN=npm_xxxxxxxx
   ```
   (Pass the token as a session variable with `set` — never write it to a file or paste it into chats/messages!)
3. Tests: `npm test` → all must pass
4. Make sure `config.yaml` and `.env` are **not tracked by git** (`.gitignore` handles it)

## 📦 What Does the npm Package Contain?

- Package contents are limited by `package.json → "files"`: `src/**/*` + `assets/**/*`
- `dist/`, `node_modules/`, `tests/`, backup folders are **not** included
- At publish time `scripts/swap-electron.js` temporarily moves `electron` into
  dependencies (prepublishOnly), then puts it back into devDependencies after
  publish (postpublish) — no manual action needed.

## 🔄 After Release

- **GitHub Releases**: the source release is visible (no exe)
- **npm users**: `beast update` (or `npm update -g beast-agent`)
- The in-app update check reads the version from the npm registry

## 🧯 Manual Fallback (if the script gets stuck)

You can do every step by hand:

```bash
# 1) edit the version manually (package.json → "version")
# 2) git
git add -A && git commit -m "v0.21.0" && git tag v0.21.0 && git push origin main --tags
# 3) GitHub release (no assets)
gh release create v0.21.0 --title "Beast Agent v0.21.0" --notes "..."
# 4) npm
set NPM_TOKEN=<token>
npm publish
# 5) OneDrive backup
robocopy . "<backup-dir>\beast-v0.21.0" /E /XD node_modules dist .git
```

## ⚠️ Known Notes

- Users who installed with the old installer can no longer auto-update —
  tell them to migrate with `npm i -g beast-agent`.
- The `electron` build (electron-builder) can still be run locally for testing
  (`npm run dist`) but it is NOT part of the release flow.
- Never write the token to a file or paste it into a chat; if you did, revoke it.

## 📦 Version Number Rules (semver)

- **patch** (0.20.0 → 0.20.1): bug fixes
- **minor** (0.20.0 → 0.21.0): new feature, new tab/command
- **major** (1.0.0): breaking change / architectural leap
