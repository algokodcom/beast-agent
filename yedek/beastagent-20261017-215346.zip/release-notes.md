## Beast Agent v2.78.0

- `npm i -g beast-agent@2.78.0`

Distribution is done via npm — the exe/installer release has been removed.
Full changelog: commit history.